#ifndef HAND_DETECT_H
#define HAND_DETECT_H

int hand_detect();


#endif
